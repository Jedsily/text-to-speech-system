def get_user_input():
    return input("Enter the text you want to convert to speech:\n")
